
# Data Sources

bbest@nceas.ucsb.edu
Jan 7, 2015

- lab1.gdb
  - [County GIS Catalog](http://cosb.countyofsb.org/gis/default.aspx?id=2802)

- rasters
  - [nlcd_2011](http://www.mrlc.gov)
  - [dem](http://www.brenorbrophy.com/California-DEM.htm)
