---
title: "Lab 4. Metrics"
author: "Ben Best"
date: "January 22, 2015"
output:
  html_document:
    toc: true
    toc_depth: 2
---

Due: noon Wed, Feb 4 2015 via GauchoSpace

# Introduction

In this lab, you'll learn about landscape metrics by exploring differences between 2 cities in Santa Barbara County.

## Getting Started

To get started:

1. Download *lab4_metrics.7z** from GauchoSpace into your course home directory (eg `H:\esm215`). Right-click on the file -> 7-Zip -> Extract Here. Navigate into the newly expanded `lab4_metrics` folder and double-click on the ArcMap document `lab4.mxd`.

1. Download *lab4.Rmd** from GauchoSpace into the lab directory (ie `H:\esm215\lab4_agents`). Right-click on it -> Open with -> RStudio.

1. Replace the working directory in the R code below with your own (be sure to replace Windows backslashes slashes with R friendly forward slashes).

# Methods

## Set Variables

You'll need to set the following variables specific to your path and desired cities for comparison (see table below for exact spelling).


```r
# set these variables
wd = 'H:/esm215/lab4_metrics'
city_a = 'Santa Barbara'
city_b = 'Goleta'
```

## Read Data, Transform and Plot


```r
# load necessary libraries having useful functions, suppressing startup messages and warnings
suppressPackageStartupMessages(suppressWarnings({
  library(reshape) # reshaping functions: rename
  library(dplyr)   # dataframe functions: select, %>%
  library(rgdal)   # read/write raster/vector data
  library(raster)  # raster functions
  library(rgeos)   # vector functions
  library(knitr)   # knitting functions: kable
  }))

# Set working directory
setwd(wd)

# read in landcover rasters, relative to working directory
nlcd_2011 = raster('raster/nlcd_2011.tif')

# read in city boundary vectors
cities = readOGR('vector', 'city_boundary_no_ocean')
```

```
## OGR data source with driver: ESRI Shapefile 
## Source: "vector", layer: "city_boundary_no_ocean"
## with 8 features and 5 fields
## Feature type: wkbPolygon with 2 dimensions
```

```r
# project, aka transform, into same coordinate system as NLCD
cities_aea = spTransform(cities, crs(nlcd_2011))

# plot landcover and projected cities on top
plot(nlcd_2011)
plot(cities_aea, border='black', lwd=2, add=T)
lbls = polygonsLabel(cities_aea, cities_aea@data$CITY, 'centroid', cex=1, doPlot=T, col='darkblue')
```

<img src="./lab4_files/figure-html/read data.png" title="plot of chunk read data" alt="plot of chunk read data" width="672" />

## Choose Two Cities in Santa Barbara County

Here are the cities of Santa Barbara County.


```r
# knit table (kable) of available city values
kable(cities_aea@data[,'CITY', drop=F], row.names=F)
```



|CITY          |
|:-------------|
|Goleta        |
|Guadalupe     |
|Lompoc        |
|Santa Maria   |
|Solvang       |
|Buellton      |
|Carpinteria   |
|Santa Barbara |

The rest of the lab is premised on chosing 2 cities (labeled `*_a` and `*_b` in code), so that we can zoom into a smaller area with mixed use and where landcover is more likely to have changed over time (versus the entire county). We'll use "Santa Barbara" (a) and "Buellton" (b) for demonstration purposes for the rest of the lab, and you'll choose a different combination of cities to similarly evaluate landcover metrics.


```r
# select city a, extract polygon and get bounding box
poly_a = cities_aea[cities_aea@data$CITY == city_a,]
bbox_a = bbox(poly_a)

# crop and mask landcover to the city
lc11_a = mask(crop(nlcd_2011, poly_a), poly_a)

# apply original color table to city landcover
lc11_a@legend@colortable = nlcd_2011@legend@colortable

# write to filesystem
setwd(wd)
writeRaster(lc11_a, 'raster/city_a_lc11.tif', overwrite=T)
```

```
## class       : RasterLayer 
## dimensions  : 270, 645, 174150  (nrow, ncol, ncell)
## resolution  : 30, 30  (x, y)
## extent      : -2153085, -2133735, 1527615, 1535715  (xmin, xmax, ymin, ymax)
## coord. ref. : +proj=aea +lat_1=29.5 +lat_2=45.5 +lat_0=23 +lon_0=-96 +x_0=0 +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs 
## data source : H:\esm215\lab4_metrics\raster\city_a_lc11.tif 
## names       : city_a_lc11 
## values      : 11, 95  (min, max)
```

```r
# plot
plot(lc11_a)

# add legend
add_legend = function(r, title=NULL, ref=nlcd_2011, lut='raster/nlcd_code2class.csv'){
  d = read.csv(lut)
  d$class = sprintf('%s - %d', d$class, d$code)
  d$colors = ref@legend@colortable[d$code+1]
  idx = d$code %in% freq(r)[,'value']
  legend(x='bottomleft', legend=d$class[idx] , fill=d$colors[idx], cex=0.7, bg='white', title=title)
}
add_legend(lc11_a, sprintf('%s 2011', city_a))
```

<img src="./lab4_files/figure-html/city a.png" title="plot of chunk city a" alt="plot of chunk city a" width="672" />


```r
# select city b, extract polygon and get bounding box
poly_b = cities_aea[cities_aea@data$CITY == city_b,]
bbox_b = bbox(poly_b)

# crop and mask landcover to the city
lc11_b = mask(crop(nlcd_2011, poly_b), poly_b)

# apply original color table to city landcover
lc11_b@legend@colortable = nlcd_2011@legend@colortable

# write to filesystem
setwd(wd)
writeRaster(lc11_b, 'raster/city_b_lc11.tif', overwrite=T)
```

```
## class       : RasterLayer 
## dimensions  : 128, 351, 44928  (nrow, ncol, ncell)
## resolution  : 30, 30  (x, y)
## extent      : -2158335, -2147805, 1533165, 1537005  (xmin, xmax, ymin, ymax)
## coord. ref. : +proj=aea +lat_1=29.5 +lat_2=45.5 +lat_0=23 +lon_0=-96 +x_0=0 +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs 
## data source : H:\esm215\lab4_metrics\raster\city_b_lc11.tif 
## names       : city_b_lc11 
## values      : 11, 95  (min, max)
```

```r
# plot
plot(lc11_b)
add_legend(lc11_b, sprintf('%s 2011', city_b))
```

<img src="./lab4_files/figure-html/city b.png" title="plot of chunk city b" alt="plot of chunk city b" width="672" />

Let's look at how many cells there are of each landcover type for both cities.

**Santa Barbara**:

```r
freq(lc11_a) %>% kable(row.names=F)
```



| value|  count|
|-----:|------:|
|    11|    122|
|    21|  16614|
|    22|  15790|
|    23|  12269|
|    24|    599|
|    31|     91|
|    42|   2090|
|    43|   2920|
|    52|   3824|
|    71|   1670|
|    90|     86|
|    95|    136|
|    NA| 117939|

**Goleta**:

```r
freq(lc11_b) %>% kable(row.names=F)
```



| value| count|
|-----:|-----:|
|    11|    83|
|    21|  3077|
|    22|  6311|
|    23|  8383|
|    24|   487|
|    31|   150|
|    42|   252|
|    43|    93|
|    52|   372|
|    71|  2173|
|    81|  1113|
|    82|   109|
|    90|    85|
|    95|   131|
|    NA| 22109|

## Setup FragStats Common Tables

Setup input files:

- **Descriptors** file provides landcover names to pixel values, and whether a given pixel is considered background.

- **Contrast** file provides values to use in determining the magnitude of edge contrast for each pairwise combination of patch types. Only applicable to specific metrics. Defaulting with highest possible contrast between all patch types (1), but should be edited to something more reasonable.

- **Similarity** file provides values to use in determining the similarity between each pairwise combination of patch types. Only applicable to specific metrics. Defaulting with lowest possible similarity between all patch types (0), but should be edited to something more reasonable.

These are all just comma-seperated value (CSV) files, so you can rename the file extension to *.csv in order to easily edit in Excel.






